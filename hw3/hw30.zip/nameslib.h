#ifndef _NAMESLIB_
#define _NAMESLIB_

const char a[] = "/tmp/hw2.fifo";

#endif
